@echo off
chcp 65001 >nul
title Istanbul Xizmatlari Avto-Post Bot
echo =========================================================
echo   ISTANBUL XIZMATLARI AVTO-POST BOT ISHGA TUSHMOQDA...
echo =========================================================
python istanbul_avtopost_bot.py
echo.
echo Dastur to'xtadi. Oynani yopish uchun istalgan tugmani bosing...
pause >nul
