# Istanbul Xizmatlari — Avtomatik Telegram Post Boti (0 dan O'rnatish Qo'llanmasi)

Ushbu qo'llanma dasturlashdan xabari bo'lmagan foydalanuvchilar uchun maxsus, oddiy tilda yozilgan. Barcha qadamlarni bir marta bajarganingizdan so'ng bot mustaqil ishlaydi.

## Bot qanday ishlaydi?

1. **Mavzu tanlash va qidiruv:** Har kuni Toshkent vaqti bilan soat **10:00** va **17:00** da bot `posts_history.json` xotira faylini tekshirib, avval chiqmagan yangi mavzuni tanlaydi va Google orqali dolzarb ma'lumotlarni qidiradi.

2. **Matn tayyorlash:** O'zbek lotin tilida sarlavha, asosiy qism, xulosa, emojilar, kanal imzosi, aloqa havolasi va hashtaglar bilan post yozadi (mavzuga qarab rasmiy yoki do'stona ohangda).

3. **Sifat nazorati (QA):** Postda grammatik xatolar yo'qligi, uzunligi (1024 belgidan oshmasligi) va *"kafolat beraman"*, *"100% kafolat"* kabi xavfli va'dalar yo'qligi tekshiriladi.

4. **Nano Banana rasm chizish:** Gemini API orqali mavzuga mos **real foto** uslubida rasm generatsiya qilinadi.

5. **Admin tasdig'i:** Tayyor rasm va post avval **sizning shaxsiy Telegram chatingizga** `✅ Tasdiqlash`, `🔄 Yangi post tayyorlash`, `🖼 Rasmni yangilash` va `❌ Rad etish` tugmalari bilan keladi. Siz **«Tasdiqlash»** tugmasini bosganingizdagina post kanalga chiqadi.

## 1-qadam: Kerakli 4 ta ma'lumotni tayyorlab olish

Botni ishga tushirishdan oldin quyidagi 4 ta narsani tayyorlab oling:

| № | Nima kerak? | Qayerdan va qanday olinadi? | Namuna | 
| ----- | ----- | ----- | ----- | 
| **1** | **Telegram Bot Token** | Telegramda `@BotFather` ga kiring -> `/newbot` deb yozing -> botga nom va `@username` bering. Sizga uzun kod (Token) beradi. | `7123456789:AAHxyz...` | 
| **2** | **Kanalda Admin huquqi** | O'zingizning «Istanbul xizmatlari» kanalingizga kiring -> *Administrators* -> *Add Admin* -> hozir ochgan botingizni qo'shing va **Post Messages** huquqini yoqing. | `@istanbul_xizmatlari` | 
| **3** | **Shaxsiy Telegram ID** | Telegramda `@userinfobot` ga kiring va `/start` bosing. U sizning raqamli ID kodingizni ko'rsatadi. | `123456789` | 
| **4** | **Gemini API Kaliti** | [Google AI Studio](https://aistudio.google.com/apikey) sahifasiga kiring -> **Create API Key** tugmasini bosing va kalitni nusxalab oling. | `AIzaSyB12345...` | 

## 2-qadam: Kompyuterga Python o'rnatish (agar o'rnatilmagan bo'lsa)

1. [python.org/downloads](https://www.python.org/downloads/) saytidan kompyuteringiz uchun Python dasturini yuklab oling.

2. O'rnatish oynasi ochilganda eng pastdagi **☑️ "Add python.exe to PATH"** katakchasiga ALBATTA belgi qo'ying va **Install Now** tugmasini bosing.

## 3-qadam: Botni ishga tushirish

1. Kompyuteringizda yangi papka oching (masalan, `IstanbulBot` deb nomlang) va `istanbul_avtopost_bot.py` faylini shu papkaga joylang.

2. Papka ichida sichqonchaning o'ng tugmasini bosib **Open in Terminal** (yoki **Buyruqlar satri / CMD**) oynasini oching va quyidagi buyruqni yozib **Enter** bosing:
   `python istanbul_avtopost_bot.py`

3. **Avtomatik sozlash:** Dastur kerakli kutubxonalarni o'zi avtomatik o'rnatadi va ekranda sizdan o'zbek tilida ketma-ket so'raydi:

   * *1. Telegram Bot Tokeningizni kiriting*

   * *2. Gemini API kalitingizni kiriting*

   * *3. Kanal @username yoki ID raqamini kiriting*

   * *4. Shaxsiy Telegram ID raqamingizni kiriting*

   * *5. Kanal imzosini kiriting*

   * *6. Aloqa havolasini kiriting*

4. Shu ma'lumotlarni kiritib **Enter** bosishingiz bilan dastur ularni `.env` fayliga saqlab oladi (keyingi safar qayta so'ramaydi) va Telegramda shaxsiy chatingizga **"🚀 Bot ishga tushdi!"** degan xabar keladi.

## 4-qadam: Telegram orqali botni boshqarish buyruqlari

Botga Telegramda shaxsiy chatdan quyidagi buyruqlarni yuborishingiz mumkin:

* `/start` — Bot holati, kanal nomi va yordam menyusini ko'rish.

* `/post` — Soat 10:00 yoki 17:00 ni kutmasdan, **hozirning o'zida** yangi post va rasm tayyorlatish.

* `/mavzu Istanbulkart olish sirlari` — O'zingiz xohlagan aniq mavzuni berib, shu mavzuda post va rasm tayyorlatish.

* `/tarix` — Kanalga chiqqan oxirgi postlar ro'yxatini ko'rish.

* `/holat` — Bot ishlayotganini va joriy Toshkent vaqtini tekshirish.

## Muhim eslatma (24/7 ishlashi uchun)

Bot har kuni soat 10:00 va 17:00 da uzluksiz ishlashi uchun dastur yoqilgan kompyuter (yoki arzon VPS server — masalan, oyiga \$4–5 turadigan Ubuntu server) yoniq va internetga ulangan bo'lishi kerak. Agar faqat o'zingiz xohlagan vaqtda kompyuterni yoqib post chiqarmoqchi bo'lsangiz, dasturni ishga tushirib Telegramdan `/post` buyrug'ini bosishingiz kifoya.