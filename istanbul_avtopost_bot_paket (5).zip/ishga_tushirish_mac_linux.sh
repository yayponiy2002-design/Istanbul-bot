#!/usr/bin/env bash
cd "$(dirname "$0")"
python3 istanbul_avtopost_bot.py
